# ItemPhysicLite — Horizon Native Mod

```
┌─────────────────────────────────────┐
│  ItemPhysicLite v1.6.13             │
│  Horizon port by ✦ Kix007 INDIA ✦  │   ← glows yellow in-game
│  Items now have real physics!        │
└─────────────────────────────────────┘
```

Port of [ItemPhysicLite](https://modrinth.com/mod/itemphysic-lite) by CreativeMD / AriaFreeze  
**Horizon port by: Kix007 INDIA**  
Original licence: LGPL-3.0-only

---

## What it does

| Behaviour | Detail |
|-----------|--------|
| Items lay flat | Non-block items set `rot_x = 0` when they land |
| Items tumble | `rot_x += speed` while airborne (speed × 2 in air) |
| Fluid drag | Spin slows by `÷ (1 + viscosity)` — water 0.014, lava 0.5, honey 0.9 |
| Block items snap | With `old_rotation = true`, block items snap to 0/90/180/270° |
| Soft-block lift | +0.1 block Y-offset on snow / soul sand / mud |
| Author credit | Yellow glowing `✦ Kix007 INDIA ✦` printed to the Horizon mod console on load |

---

## Requirements

| | Minimum |
|-|---------|
| Horizon | 0.2.97 |
| horizon-mixins | d9c83d7 |
| Rust toolchain | stable |

---

## Build & install

```bash
# 1 — clone / download this folder
# 2 — build and install in one command:
horizon-launcher native-build itemphysic-horizon/ --trust-native-code
```

The launcher compiles the Rust source, links it into the game, and adds the
mod to your active profile.  No manual file copying needed.

---

## Configuration

`config/itemphysic_lite.txt` is created automatically on first launch:

```
# ItemPhysicLite — Horizon port by Kix007 INDIA
# rotate_speed : item spin speed multiplier (default 1.0, try 0.5 or 2.0)
# old_rotation  : snap block-items to 0/90/180/270 deg when on the ground
rotate_speed = 1.0
old_rotation = false
```

Horizon reloads the file when you save it — no restart needed.

---

## File structure

```
itemphysic-horizon/
├── rust-toolchain.toml          stable Rust pin
├── Cargo.toml                   workspace root
├── compatibility.json           Horizon + horizon-mixins version pins
├── README.md
└── mixins/
    └── itemphysic_lite/
        ├── Cargo.toml           crate metadata (author: Kix007 INDIA)
        ├── horizon-mixin.toml   hook declarations + §e§l author field
        └── src/
            ├── lib.rs           crate root + init entry point
            ├── config.rs        config file loader
            ├── state.rs         per-entity rotation store
            ├── tick.rs          TAIL hook on ItemEntity#tick
            ├── render.rs        render-state + pose override hooks
            └── splash.rs        §e§l yellow-glow author credit
```

---

## How it was converted

The original JAR was decompiled with `javap -c` to recover the full bytecode of
`ClientPhysic.calculateRotation`, `ItemEntityRenderStateMixin`, `ItemEntityMixin`,
and `ItemPhysicLiteConfig`.  Every constant, branch, and formula was ported
directly to Rust — no guessing.

The `creativecore` SortingList dependency from the Java mod is replaced by a
simple Rust `const` array for the offset-blocks list.
