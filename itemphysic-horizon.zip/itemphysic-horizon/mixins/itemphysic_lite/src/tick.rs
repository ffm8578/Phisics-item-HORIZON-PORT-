// tick.rs — per-tick rotation update
//
// Direct port of ClientPhysic.calculateRotation() (decompiled from bytecode).
//
// Java logic (reconstructed):
//   speed = deltaTime * 0.25 * rotateSpeed
//   if paused: speed = 0
//   if stuckSpeedMultiplier.lengthSqr > 0: speed *= stuck.x * 0.2
//
//   if isBlock:
//     if !onGround:  speed*=2; if inFluid speed/=(1+viscosity); xRot+=speed
//     elif oldRotation: snap xRot to nearest 0/90/180/270
//   else:
//     if validPos && onGround: xRot = 0        ← lay flat
//     elif !onGround: speed*=2; fluid drag; xRot+=speed

use horizon_api::mixin::{ItemEntityMixin, CallbackInfo};
use crate::{config, state};

// ── Fluid viscosity constants ─────────────────────────────────────────────────
// Values from original ItemPhysicLite.getViscosity()
const VISCOSITY_WATER:    f32 = 0.014;
const VISCOSITY_LAVA:     f32 = 0.5;
const VISCOSITY_HONEY:    f32 = 0.9;   // modded fluid fallback
const VISCOSITY_DEFAULT:  f32 = 0.014; // unknown fluid → treat like water

fn fluid_viscosity(fluid_id: &str) -> f32 {
    match fluid_id {
        "minecraft:water" | "minecraft:flowing_water" => VISCOSITY_WATER,
        "minecraft:lava"  | "minecraft:flowing_lava"  => VISCOSITY_LAVA,
        id if id.contains("honey")     => VISCOSITY_HONEY,
        _                              => VISCOSITY_DEFAULT,
    }
}

// ── Cardinal-angle snapping (old_rotation mode) ───────────────────────────────
fn snap_toward_nearest_cardinal(angle: f32, step: f32) -> f32 {
    // Find the nearest of 0, 90, 180, 270.
    let cardinals = [0.0_f32, 90.0, 180.0, 270.0];
    let target = *cardinals
        .iter()
        .min_by(|&&a, &&b| (angle - a).abs().partial_cmp(&(angle - b).abs()).unwrap())
        .unwrap();
    if (angle - target).abs() < step {
        target              // already close enough — snap exactly
    } else if angle < target {
        angle + step
    } else {
        angle - step
    }
}

// ── Hook handler ─────────────────────────────────────────────────────────────
/// Injected at TAIL of ItemEntity#tick (client-side only).
///
/// Horizon passes the entity through the mixin context.  The function
/// signature must match the hook declaration in horizon-mixin.toml.
#[no_mangle]
pub extern "C" fn on_item_entity_tick(ctx: &mut ItemEntityMixin, _ci: &mut CallbackInfo) {
    // Skip on the server — we only do client-side visual rotation.
    if !ctx.level().is_client_side() { return; }

    let cfg = config::get();
    let id  = ctx.entity_id();

    // Base speed: matches Java `deltaTime * 0.25f * config.rotateSpeed`
    // Horizon provides get_partial_tick() on the client context.
    let delta = ctx.partial_tick();
    let mut speed = delta * 0.25 * cfg.rotate_speed;

    // If the game is currently paused the renderer still runs but physics stop.
    if ctx.is_paused() { speed = 0.0; }

    // stuckSpeedMultiplier: active when entity is in cobweb / honey / powder snow.
    let stuck = ctx.stuck_speed_multiplier(); // returns (x, y, z) as f32 tuple
    let stuck_len_sq = stuck.0 * stuck.0 + stuck.1 * stuck.1 + stuck.2 * stuck.2;
    if stuck_len_sq > 0.0 {
        speed *= stuck.0 * 0.2;
    }

    let mut s = state::get(id);
    let is_block = s.is_block;        // set by render hook previous frame
    let on_ground = ctx.on_ground();

    // Fluid check: returns Some("minecraft:water") etc., or None.
    let fluid = ctx.touching_fluid_id();

    if is_block {
        // ── Block-type item (stone, wood, etc. dropped as a block) ────────────
        if !on_ground {
            speed *= 2.0;
            if let Some(ref fid) = fluid {
                speed /= 1.0 + fluid_viscosity(fid);
            }
            s.rot_x += speed;
        } else if cfg.old_rotation {
            s.rot_x = snap_toward_nearest_cardinal(s.rot_x, speed);
        }
    } else {
        // ── Non-block item (sword, apple, etc.) ───────────────────────────────
        let pos = ctx.position();           // returns (x, y, z) as f64 tuple
        let pos_valid = !pos.0.is_nan() && !pos.1.is_nan() && !pos.2.is_nan();

        if pos_valid && on_ground {
            s.rot_x = 0.0;                  // lay flat
        } else if !on_ground {
            speed *= 2.0;
            if let Some(ref fid) = fluid {
                speed /= 1.0 + fluid_viscosity(fid);
            }
            s.rot_x += speed;
        }
    }

    state::set(id, s);
}
