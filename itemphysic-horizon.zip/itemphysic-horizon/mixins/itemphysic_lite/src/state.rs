// state.rs — per-entity physics state
//
// Horizon item entities don't carry extra fields, so we keep our own
// per-entity data in a client-side HashMap<u32, ItemPhysicState>.
// A Mutex guards it because extract_render_state and tick can run on
// different threads in Horizon.

use std::collections::HashMap;
use std::sync::Mutex;

/// Physics data we track for each live item entity.
#[derive(Debug, Clone, Default)]
pub struct ItemPhysicState {
    /// Rotation around the X axis (degrees).  Starts at 0.
    pub rot_x: f32,
    /// True when the item renders with block-lighting (i.e. it is a block item).
    /// Set by the render-state hook each frame; used by the tick hook next tick.
    pub is_block: bool,
    /// True when the item sits on snow / soul-sand / mud and needs a Y lift.
    pub additional_offset: bool,
}

static STATES: Mutex<Option<HashMap<u32, ItemPhysicState>>> = Mutex::new(None);

fn with_map<R>(f: impl FnOnce(&mut HashMap<u32, ItemPhysicState>) -> R) -> R {
    let mut g = STATES.lock().unwrap();
    f(g.get_or_insert_with(HashMap::new))
}

pub fn get(id: u32) -> ItemPhysicState {
    with_map(|m| m.get(&id).cloned().unwrap_or_default())
}

pub fn set(id: u32, s: ItemPhysicState) {
    with_map(|m| { m.insert(id, s); });
}

pub fn update_rot_x(id: u32, rot_x: f32) {
    with_map(|m| m.entry(id).or_default().rot_x = rot_x);
}

/// Call when an item entity leaves the level to free memory.
#[allow(dead_code)]
pub fn remove(id: u32) {
    with_map(|m| { m.remove(&id); });
}
