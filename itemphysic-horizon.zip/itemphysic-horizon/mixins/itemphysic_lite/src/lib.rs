// ItemPhysicLite — Horizon Native Mod
// ─────────────────────────────────────────────────────────────────────────────
// Ported from: ItemPhysicLite_FABRIC_v1.6.13_mc26.3
// Original authors: CreativeMD, AriaFreeze
// Original licence: LGPL-3.0-only
//
// Horizon port by: Kix007 INDIA
// ─────────────────────────────────────────────────────────────────────────────
//
// What this mod does:
//   • Dropped items lay flat on the ground instead of hovering and spinning.
//   • Items tumble (spin on the X axis) while they fall through the air.
//   • Spin slows down in fluids (water, lava, honey) based on viscosity.
//   • Items on snow / soul sand / mud get a small Y-lift to avoid z-fighting.
//   • Config: config/itemphysic_lite.txt (auto-created on first launch).
//
// Architecture:
//   state  — per-entity rotation store (HashMap<EntityId, ItemPhysicState>)
//   config — load/reload itemphysic_lite.txt
//   tick   — TAIL hook on ItemEntity#tick: updates rot_x each game tick
//   render — TAIL hook on extractRenderState + HEAD hook on render

pub mod config;
pub mod state;
pub mod tick;
pub mod render;
pub mod splash;

/// Mod entry point — called once by the Horizon launcher after all hooks
/// have been registered.  Prints the yellow author credit to the game console.
#[no_mangle]
pub extern "C" fn itemphysic_lite_init() {
    splash::print_credit();
}
