// splash.rs — author credit printed to the Horizon mod console on load.
//
// §e = yellow   §l = bold (creates a "glow" effect in Minecraft text)
// §r = reset    §6 = gold (used for the border)

/// Printed to the Horizon mod loader console when the mod initialises.
/// The §-codes render in the in-game mod list and log viewer.
pub const CREDIT: &str = concat!(
    "§6┌─────────────────────────────────────┐\n",
    "§6│  §aItemPhysicLite §7v1.6.13             §6│\n",
    "§6│  §7Horizon port by §e§l✦ Kix007 INDIA ✦§r  §6│\n",
    "§6│  §7Items now have real physics!         §6│\n",
    "§6└─────────────────────────────────────┘",
);

/// Called once from the mod entry point to print the credit.
pub fn print_credit() {
    // horizon_api::log::info renders §-colour codes in the game console.
    horizon_api::log::info(CREDIT);
}
