// render.rs — render-state extraction + pose override
//
// Two hooks mirror the two Mixin classes in the original mod:
//
//   on_extract_render_state
//       ← ItemEntityRenderStateMixin#extractPhysic
//       Runs at TAIL of ItemEntityRenderer#extractRenderState.
//       Reads is_block from the render snapshot and stores it so the
//       tick hook can use it next frame.  Also sets additional_offset.
//
//   on_item_render
//       ← ItemEntityRendererMixin#injectExtract
//       Runs at HEAD of ItemEntityRenderer#render.
//       Replaces the vanilla hover-spin rotation with our physics rotation.

use horizon_api::mixin::{
    ItemEntityRenderStateMixin, ItemEntityRendererMixin, CallbackInfo,
};
use crate::state;

/// Blocks that require a Y-offset (snow, soul sand, mud).
/// Mirrors the default ItemPhysicLiteConfig.blockRequireOffset list.
const OFFSET_BLOCKS: &[&str] = &[
    "minecraft:snow",
    "minecraft:soul_sand",
    "minecraft:mud",
];

fn needs_offset(block_id: &str) -> bool {
    OFFSET_BLOCKS.contains(&block_id)
}

// ── Hook 1: extract render state ─────────────────────────────────────────────

/// Injected at TAIL of ItemEntityRenderer#extractRenderState.
///
/// At this point the render snapshot is fully populated; we read is_block
/// from it and persist it in our state map for the tick hook.
#[no_mangle]
pub extern "C" fn on_extract_render_state(
    ctx: &mut ItemEntityRenderStateMixin,
    _ci: &mut CallbackInfo,
) {
    let id = ctx.entity_id();
    let mut s = state::get(id);

    // is_block = the item stack uses block-light rendering.
    s.is_block = ctx.item_stack_uses_block_light();

    // Check the block at and directly below the item for offset blocks.
    let block_at    = ctx.block_id_at_position();
    let block_below = ctx.block_id_below();
    s.additional_offset =
        needs_offset(&block_at) || needs_offset(&block_below);

    state::set(id, s);
}

// ── Hook 2: override render pose ─────────────────────────────────────────────

/// Injected at HEAD of ItemEntityRenderer#render.
///
/// We apply our physics rotation (rot_x) to the PoseStack before the
/// vanilla renderer draws the item, suppressing the default hover-spin.
#[no_mangle]
pub extern "C" fn on_item_render(
    ctx: &mut ItemEntityRendererMixin,
    _ci: &mut CallbackInfo,
) {
    let id = ctx.entity_id();
    let s  = state::get(id);

    // Apply Y-offset for items sitting on soft blocks.
    if s.additional_offset {
        ctx.pose_translate(0.0, 0.1, 0.0);
    }

    // Cancel the vanilla Y hover-spin and apply our angles instead.
    // rot_y: entity's own yRot (direction it was thrown) — unchanged by this mod.
    // rot_x: our accumulated tumble angle.
    let rot_y = ctx.entity_y_rot();     // degrees
    let rot_x = s.rot_x;               // degrees

    ctx.pose_cancel_vanilla_rotation(); // suppress the default bob/spin
    ctx.pose_rotate_y(rot_y.to_radians());
    ctx.pose_rotate_x(rot_x.to_radians());
}
