// config.rs
//
// Loads / reloads itemphysic_lite.txt.
// Default values match the decompiled ItemPhysicLiteConfig constructor.

use std::sync::RwLock;

#[derive(Debug, Clone)]
pub struct Config {
    /// Rotation speed multiplier (default 1.0).
    pub rotate_speed: f32,
    /// Snap block-items to 0/90/180/270° when resting (default false).
    pub old_rotation: bool,
}

impl Default for Config {
    fn default() -> Self {
        Config { rotate_speed: 1.0, old_rotation: false }
    }
}

static CONFIG: RwLock<Config> = RwLock::new(Config { rotate_speed: 1.0, old_rotation: false });

pub fn get() -> Config {
    CONFIG.read().unwrap().clone()
}

/// Called by Horizon when itemphysic_lite.txt is loaded or reloaded.
/// `source` is the full file text.
pub fn on_config_load(source: &str) {
    let mut cfg = Config::default();
    for line in source.lines() {
        let line = line.trim();
        if line.starts_with('#') || line.is_empty() { continue; }
        if let Some((k, v)) = line.split_once('=') {
            match k.trim() {
                "rotate_speed" => {
                    if let Ok(f) = v.trim().parse::<f32>() { cfg.rotate_speed = f; }
                }
                "old_rotation" => {
                    cfg.old_rotation = v.trim().eq_ignore_ascii_case("true");
                }
                _ => {}
            }
        }
    }
    *CONFIG.write().unwrap() = cfg;
}

/// Written to disk when the config file does not exist yet.
pub const DEFAULT_CONFIG: &str = "\
# ItemPhysicLite — Horizon port by Kix007 INDIA
# rotate_speed : item spin speed multiplier (default 1.0, try 0.5 or 2.0)
# old_rotation  : snap block-items to 0/90/180/270 deg when on the ground
rotate_speed = 1.0
old_rotation = false
";
